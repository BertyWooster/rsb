import time
import traceback
from datetime import datetime
import redis
from .utils import *


class Worker:
    def __init__(
        self,
        redis_host,
        redis_port=DEFAULT_REDIS_PORT,
        timeout=DEFAULT_TIMEOUT_SEC,
        polling_period=DEFAULT_POLLING_PERIOD_SEC,
    ):

        self.mq = redis.StrictRedis(host=redis_host, port=redis_port, db=0)
        self.polling_period = polling_period
        self.updater = StatusUpdater(
            host=redis_host,
            port=redis_port,
            timeout=timeout,
            polling_period=polling_period,
        )

        logging.info("worker ready!")

    def run(self, task_map: dict):

        for task_type in task_map:
            self.mq.sadd("REGISTERED_OPERATORS", task_type)

        while True:
            task = BaseMessage(
                workflow=[],
                id="-1",
                timestamp=datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
            )

            try:
                time.sleep(self.polling_period)  # reduce cpu usage while wait
                for task_type in task_map:

                    if self.mq.llen(task_type) != 0:
                        task = BaseMessage(
                            **json.loads(self.mq.rpop(task_type)))
                        logger.info(
                            f"received task '{task.id}'")

                        self.updater.set_in_progress(task)
                        task.stage = task_type
                        job = task_map[task_type]
                        response_data = job(task.data)

                        if task.workflow.index(task_type) == len(task.workflow) - 1:
                            self.updater.set_success(task, response_data)
                            logger.info(f"task succeeded '{task.id}'")

                            if task.webhook:
                                self.updater.send_webhook_post(task, task.webhook)

                        else:
                            next_task_type = task.workflow[task.workflow.index(
                                task_type) + 1]
                            task.stage = next_task_type
                            task = self.updater.set_created(
                                task, response_data)
                            self.mq.lpush(next_task_type,
                                          json.dumps(task.dict()))
                            logger.info(
                                f"stage completed '{task.id}', push to '{next_task_type}'")

            except:
                try:
                    self.updater.set_error(
                        task, json.dumps(traceback.format_exc()))
                    logger.error(
                        f"task '{task.id} failed'. Traceback: {traceback.format_exc()}")
                except Exception:
                    logger.error(
                        f"incorrect task. Check if task is not None. Traceback: {traceback.format_exc()}")
                    
                if task.webhook:
                    self.updater.send_webhook_post(task, task.webhook)
