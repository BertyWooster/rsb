import traceback
import redis
from .utils import *


class Inspector:
    def __init__(
        self,
        redis_host,
        redis_port=DEFAULT_REDIS_PORT,
        timeout=DEFAULT_TIMEOUT_SEC,
        polling_period=DEFAULT_POLLING_PERIOD_SEC,
    ):
        
        raise NotImplementedError()
    
        self.rs_status = redis.StrictRedis(host=redis_host, port=redis_port, db=1)
        ...
        

    def run(self):

        raise NotImplementedError()

        while True:
            ...
