import os
from typing import Optional

import aiomysql


class MYSQLEventsLogger:
    """Mysql based logger для записи событий юзеров в базу данных"""

    def __init__(
        self,
        host,
        port,
        user,
        password,
        db,
        db_table,
    ):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.db = db
        self.db_table = db_table
        self.pool_size = int(os.environ.get("MYSQL_POOL_SIZE", 10))
        self.pool = None

    async def create_database(self):
        conn = await aiomysql.connect(
            host=self.host,
            port=self.port,
            user=self.user,
            password=self.password,
        )
        async with conn.cursor() as cur:
            await cur.execute(f"CREATE DATABASE IF NOT EXISTS {self.db}")
        conn.close()

    async def create_table(self):
        conn = await aiomysql.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            db=self.db,
        )
        async with conn.cursor() as cur:
            await cur.execute(
                f"CREATE TABLE IF NOT EXISTS {self.db_table} (user_id VARCHAR(255), task_id VARCHAR(255), event_time TIMESTAMP, event_data VARCHAR(255))"
            )
        conn.close()

    async def create_pool(self):
        self.pool = await aiomysql.create_pool(
            minsize=self.pool_size,
            maxsize=self.pool_size,
            host=self.host,
            user=self.user,
            password=self.password,
            db=self.db,
        )

    async def write_event(
        self, user_id: str, event_data: str, task_id: Optional[str] = None
    ):
        async with self.pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"INSERT INTO {self.db_table} (user_id, task_id, event_time, event_data) VALUES (%s, %s, CURRENT_TIMESTAMP(), %s)",
                    (user_id, task_id, event_data),
                )
            await conn.commit()

    async def get_events_by_user_id(self, user_id):
        async with self.pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"SELECT * FROM {self.db_table} WHERE user_id = %s", (user_id,)
                )
                events = await cur.fetchall()
        return events

    async def get_events_by_task_id(self, task_id):
        async with self.pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"SELECT * FROM {self.db_table} WHERE task_id = %s", (task_id,)
                )
                events = await cur.fetchall()
        return events

    async def initialize(self):
        await self.create_database()
        await self.create_table()
        await self.create_pool()
