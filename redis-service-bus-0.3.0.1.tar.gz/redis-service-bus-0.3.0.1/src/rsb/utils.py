import json
import logging
import time
from datetime import datetime
from typing import Dict, List, Optional
import redis
from pydantic import BaseModel
import requests
import traceback

REDIS_KEY_EXP_TIME_SEC = 12 * 3600
DEFAULT_REDIS_PORT = 6379
DEFAULT_TIMEOUT_SEC = 300
DEFAULT_POLLING_PERIOD_SEC = 0.1


class BaseMessage(BaseModel):
    id: str
    timestamp: str
    high_priority: bool = False
    workflow: List[str]
    status: Optional[str]
    data: Optional[Dict]
    stage: Optional[str]
    traceback: Optional[str]
    webhook: Optional[str]


def get_logger():
    logging.basicConfig(
        level=logging.INFO,
        format=json.dumps(
            {
                "time": "%(asctime)s",
                "level": "%(levelname)s",
                "func": "%(funcName)s",
                "message": "%(message)s",
            }
        ),
        datefmt="%Y-%m-%dT%H:%M:%S",
    )

    class MessageFilter(logging.Filter):
        def filter(self, record):
            record.msg = json.dumps(record.msg)[1:-1]
            return record

    logger = logging.getLogger()
    logger.addFilter(MessageFilter())

    return logger


logger = get_logger()


class StatusUpdater:
    def __init__(self, host, port, timeout: int, polling_period: float):
        self.timeout = timeout
        self.polling_period = polling_period
        self.rs_status = redis.StrictRedis(host=host, port=port, db=1)

    def set_created(self, task, task_data) -> BaseMessage:

        task.timestamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f")
        task.status = "CREATED"
        task.stage = task.stage

        self.rs_status.set(task.id, json.dumps(task.dict()), ex=REDIS_KEY_EXP_TIME_SEC)
        task.data = task_data
        return task

    def get_by_id(self, task_id: str) -> BaseMessage:
        return BaseMessage(**json.loads(self.rs_status.get(task_id)))

    def wait_until_complete(self, task: BaseMessage) -> BaseMessage:
        time_passed = 0

        while True:
            result = self.get_by_id(task.id)
            if result.status == "ERROR" or result.status == "SUCCESS":
                return result

            time.sleep(self.polling_period)

            time_passed = round(time_passed, len(str(self.polling_period)) - 2)
            if time_passed % 5 == 0:  # log progress every 5 seconds
                logger.info(f"still wait response after {int(time_passed)} seconds")

            if time_passed > self.timeout:
                logger.warning("timeout!")
                return self.get_timeout(result)

            time_passed += self.polling_period

    def set_in_progress(self, task: BaseMessage) -> None:
        if self.get_by_id(task.id).status in ["ERROR", "SUCCESS"]:
            return None

        task.timestamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f")
        task.status = "IN PROGRESS"

        self.rs_status.set(task.id, json.dumps(task.dict()), ex=REDIS_KEY_EXP_TIME_SEC)

    def set_success(self, task: BaseMessage, response_data: Dict) -> None:
        if self.get_by_id(task.id).status in ["ERROR", "SUCCESS"]:
            return None

        task.timestamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f")
        task.status = "SUCCESS"
        task.data = response_data

        self.rs_status.set(task.id, json.dumps(task.dict()), ex=REDIS_KEY_EXP_TIME_SEC)

    def set_error(self, task: BaseMessage, traceback: str) -> None:
        if self.get_by_id(task.id).status in ["ERROR", "SUCCESS"]:
            return None

        task.timestamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f")
        task.status = "ERROR"
        task.traceback = traceback

        self.rs_status.set(task.id, json.dumps(task.dict()), ex=REDIS_KEY_EXP_TIME_SEC)

    def get_timeout(self, task: BaseMessage) -> BaseMessage:
        return BaseMessage(
            workflow=task.workflow,
            id=task.id,
            timestamp=datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
            status="TIMEOUT",
        )

    def remove_task_result(self, task_id):
        self.rs_status.delete(task_id)
        return 0

    def send_webhook_post(self, task, url):
        try:
            r = requests.post(url, json=task.json())
            logger.info(
                f"post to webhook {url} for task '{task.id}' completed with status {r.status_code}"
            )
        except:
            logger.error(
                f"post to webhook {url} failed! Traceback: {traceback.format_exc()}"
            )
