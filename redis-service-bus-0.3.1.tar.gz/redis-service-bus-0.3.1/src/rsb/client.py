import hashlib
from .utils import *


class Client:
    def __init__(
        self,
        redis_host,
        redis_port=DEFAULT_REDIS_PORT,
        timeout=DEFAULT_TIMEOUT_SEC,
        polling_period=DEFAULT_POLLING_PERIOD_SEC,
    ):

        self.mq = redis.StrictRedis(host=redis_host, port=redis_port, db=0)
        self.updater = StatusUpdater(
            host=redis_host,
            port=redis_port,
            timeout=timeout,
            polling_period=polling_period,
        )

    def getLoad(self, workflow: List[str] = None):

        load = {}

        if workflow:
            for node in workflow:
                load[node] = self.mq.llen(node)
        else:
            for node in self.mq.smembers("REGISTERED_OPERATORS"):
                load[node.decode()] = self.mq.llen(node)

        return load

    def getTask(self, task_id: str) -> Dict:
        return self.updater.get_by_id(task_id).dict()

    def pushTask(self, task_data: Dict, workflow: List[str], wait_result=False, webhook=None, high_priority=False) -> Dict:
        try:

            task = BaseMessage(
                id=f"{hashlib.md5(json.dumps(task_data).encode()).hexdigest()}_{round(time.time() * 1000)}",
                workflow=workflow,
                timestamp=datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f")
            )

            if webhook:
                task.webhook = webhook

            task = self.updater.set_created(task, task_data)
            if high_priority:
                self.mq.rpush(workflow[0], json.dumps(task.dict()))
            else:
                self.mq.lpush(workflow[0], json.dumps(task.dict()))
            logger.info("task created")

            if wait_result:
                result = self.updater.wait_until_complete(task)
                logger.info(f"return response")
                return result.dict()
            else:
                result = self.updater.get_by_id(task.id)
                logger.info(f"return id")
                return result.dict()
        except:
            logger.error(traceback.format_exc())
